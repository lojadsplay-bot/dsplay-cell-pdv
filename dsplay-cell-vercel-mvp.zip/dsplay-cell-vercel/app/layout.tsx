import './globals.css'
export const metadata = { title: 'DSplay Cell PDV', description: 'PDV online para DSplay Cell' }
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="pt-BR"><body>{children}</body></html> }
